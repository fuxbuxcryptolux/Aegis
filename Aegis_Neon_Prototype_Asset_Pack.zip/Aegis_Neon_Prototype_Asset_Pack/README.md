# Aegis Neon Prototype Asset Pack

Prepared for direct Copilot/GitHub handoff.

## Runtime organization

- `sprites/enemies/` — one 256x256-cell atlas per enemy class.
- `sprites/bosses/` — large standalone boss PNGs.
- `sprites/squad/` — Castle Squad atlas.
- `sprites/turrets/` — fantasy turret atlas.
- `manifest.json` — exact atlas ordering and runtime paths.
- `reference/` — original source packs used for preprocessing; not required at runtime.

## Enemy rule

Each enemy class uses one canonical static pose. The same pose is represented in seven neon variants:

Pink, Cyan, Green, Yellow, Orange, Red, Purple.

This avoids 7 separately authored poses per class and keeps the art pipeline consistent.

## Current prototype art

Enemy classes:
- Ghost
- Goblin
- Gnome
- Troll

Boss:
- Demon Lord — raised flaming sword / charging pose

Castle Squad:
- Blacksmith
- Arcanist
- Ranger
- Vanguard

Turrets:
- Archer Tower
- Mage Tower
- Ballista Tower
- Frost Tower
- Poison Tower
- Lightning Tower
- Fire Tower
- Heal Tower
- Barrier Tower

Future art slots are documented in `manifest.json` but are not invented here.

## Copilot integration guidance

Use `manifest.json` rather than hard-coding individual crop coordinates in the renderer. The Canvas renderer can select a source rectangle from each atlas with `drawImage(image, sx, sy, sw, sh, dx, dy, dw, dh)`.

Do not modify the artwork or recolor it dynamically unless specifically requested. The current neon colors are already baked into the sprites.

Do not delete the procedural renderer until the asset-backed renderer has a verified fallback.
