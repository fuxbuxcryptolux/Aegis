# COPILOT HANDOFF — Aegis Neon Runtime Assets

## Objective
Integrate the supplied Aegis prototype art into PR #1 without changing the approved art.

## Runtime assets supplied
### Enemy atlases
- `sprites/enemies/ghost_neon.png`
- `sprites/enemies/goblin_neon.png`
- `sprites/enemies/gnome_neon.png`
- `sprites/enemies/troll_neon.png`

Each enemy atlas is a 7-column strip using this order:
1. pink
2. cyan
3. green
4. yellow
5. orange
6. red
7. purple

Each cell is 256x256.

### Boss
- `sprites/bosses/demon_lord.png`
- Approved pose: raised flaming sword / charging attack

### Castle Squad
- `sprites/squad/castle_squad.png`
- 4 columns, 320x320 cells
- Order: blacksmith, arcanist, ranger, vanguard

### Turrets
- `sprites/turrets/turret_atlas.png`
- 9 columns, 256x256 cells
- Order:
  archer_tower, mage_tower, ballista_tower, frost_tower,
  poison_tower, lightning_tower, fire_tower, heal_tower, barrier_tower

## Integration rules
1. Copy runtime assets into the repository's public sprite path.
2. Use `manifest.json` for runtime lookup; do not scatter magic crop coordinates through JSX/engine code.
3. Replace the side-view prototype's procedural enemy renderer with the asset-backed renderer.
4. Keep the procedural renderer only as a deterministic fallback when an image fails to load.
5. Preserve image aspect ratio and transparent edges.
6. Do not dynamically recolor the supplied sprites; the seven neon colors are already authored in the assets.
7. For enemies, render one static pose per class and select color by atlas column.
8. Bosses use standalone assets and may be scaled larger.
9. Castle Squad uses the supplied character art; Blacksmith is a person/character, not an anvil icon.
10. Turrets use the supplied fantasy-themed artwork and are not futuristic year-3000 machinery.
11. Do not add the non-neon versions to the runtime path.
12. Do not alter the permanent Gem economy.
13. Keep the top-down production mode untouched.
14. Keep the prototype isolated behind `?mode=sideview`.

## Validation
Run:
- `npm test -- --watchAll=false`
- `npm run build`

Add focused tests for:
- manifest lookup
- sprite-column selection
- missing-asset fallback
- boss asset resolution
- Castle Squad asset resolution
- turret asset resolution

## Current and future art
Current runtime prototype assets are limited intentionally.

Not yet supplied:
- `nuclear_behemoth`
- `master_necromancer`
- `skeleton`
- `slime`
- `shadow_hound`

Do not invent replacement artwork for these classes. Keep them as documented future slots/configuration.

## PR policy
Do not merge automatically.
Report:
- changed files
- runtime asset paths
- manifest mapping
- tests
- build result
- remaining art gaps
